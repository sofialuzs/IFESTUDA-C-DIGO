-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 15/12/2024 às 19:14
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `ppi2`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `pessoa`
--

CREATE TABLE `pessoa` (
  `usuario_id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pessoa`
--

INSERT INTO `pessoa` (`usuario_id`, `nome`, `email`, `senha`) VALUES
(2, 'Sofia', 'sofia@gmail.com', 'senha');

-- --------------------------------------------------------

--
-- Estrutura para tabela `questoes`
--

CREATE TABLE `questoes` (
  `id` int(11) NOT NULL,
  `disciplina` varchar(255) NOT NULL,
  `enunciado` text NOT NULL,
  `alternativa_a` text NOT NULL,
  `alternativa_b` text NOT NULL,
  `alternativa_c` text NOT NULL,
  `alternativa_d` text NOT NULL,
  `resposta_correta` enum('alternativa_a','alternativa_b','alternativa_c','alternativa_d') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `questoes`
--

INSERT INTO `questoes` (`id`, `disciplina`, `enunciado`, `alternativa_a`, `alternativa_b`, `alternativa_c`, `alternativa_d`, `resposta_correta`) VALUES
(1, 'Fundamento de Sistemas Operacionais', 'O que é um Sistema Operacional?', 'Um tipo de banco de dados', 'Software que gerencia hardware e software', 'Um tipo de linguagem de programação', 'Um programa de edição de texto', 'alternativa_b'),
(2, 'Sistemas Operacionais', 'Qual é a principal função de um Sistema Operacional?', 'Gerenciar recursos do computador', 'Desenvolver software', 'Gerenciar a comunicação de redes', 'Criptografar arquivos', 'alternativa_a'),
(3, 'Sistemas Operacionais', 'O que é um processo em um Sistema Operacional?', 'Um tipo de memória', 'Um arquivo de sistema', 'Um programa em execução', 'Um tipo de rede', 'alternativa_c'),
(4, 'Sistemas Operacionais', '1. O que é um Sistema Operacional?', 'Um tipo de banco de dados', 'Software que gerencia hardware e software', 'Um tipo de linguagem de programação', 'Um programa de edição de texto', 'alternativa_b'),
(5, 'Sistemas Operacionais', '2. Qual é a principal função de um Sistema Operacional?', 'Gerenciar recursos do computador', 'Desenvolver software', 'Gerenciar a comunicação de redes', 'Criptografar arquivos', 'alternativa_a'),
(6, 'Sistemas Operacionais', '3. O que é um processo em um Sistema Operacional?', 'Um tipo de memória', 'Um arquivo de sistema', 'Um programa em execução', 'Um tipo de rede', 'alternativa_c'),
(7, 'Sistemas Operacionais', '4. O que é um sistema multitarefa?', 'Sistema que gerencia múltiplos usuários simultaneamente', 'Sistema que gerencia apenas um tipo de dispositivo', 'Sistema que gerencia múltiplos processos simultaneamente', 'Sistema que gerencia apenas um processo por vez', 'alternativa_c'),
(8, 'Manutenção', 'O que significa a sigla \'PM\' na área de manutenção?', 'Planejamento de Manutenção', 'Prevenção de Manutenção', 'Manutenção Preventiva', 'Programação de Manutenção', 'alternativa_c'),
(9, 'Manutenção', 'Qual é a principal função da manutenção corretiva?', 'Evitar falhas em equipamentos', 'Corrigir falhas já ocorridas nos equipamentos', 'Monitorar o desempenho de máquinas', 'Planejar a substituição de peças', 'alternativa_b'),
(10, 'Manutenção', 'Qual tipo de manutenção é realizada antes que uma falha ocorra?', 'Manutenção corretiva', 'Manutenção preventiva', 'Manutenção preditiva', 'Manutenção de emergência', 'alternativa_b'),
(11, 'Manutenção', 'O que é uma \"manutenção preditiva\"?', 'Ações de manutenção baseadas na previsão de falhas com base em dados coletados', 'Manutenção realizada após a falha do equipamento', 'Manutenção realizada para evitar falhas futuras', 'Ações que visam apenas a limpeza do equipamento', 'alternativa_a'),
(12, 'Manutenção', 'Qual é o objetivo principal da manutenção preventiva?', 'Aumentar o tempo de operação dos equipamentos sem falhas', 'Substituir as peças gastas', 'Ajustar o sistema operacional de equipamentos', 'Evitar paradas inesperadas de máquinas e sistemas', 'alternativa_d'),
(13, 'Manutenção', 'Qual tipo de manutenção é mais indicado para equipamentos críticos e de alto custo?', 'Manutenção preventiva', 'Manutenção corretiva', 'Manutenção preditiva', 'Manutenção de emergência', 'alternativa_c'),
(14, 'Manutenção', 'O que caracteriza a manutenção corretiva?', 'É realizada quando o equipamento apresenta falha', 'É realizada com base na previsão de falhas', 'É realizada periodicamente, independente do estado do equipamento', 'É realizada para melhorar o desempenho do equipamento', 'alternativa_a'),
(15, 'Manutenção', 'A manutenção de emergência é realizada quando?', 'Quando há uma falha inesperada e o equipamento para de funcionar', 'Quando a manutenção preventiva não é suficiente', 'Quando é necessário substituir peças desgastadas', 'Quando há um aumento no desempenho do equipamento', 'alternativa_a'),
(16, 'Manutenção', 'Quais fatores devem ser considerados em um plano de manutenção?', 'Tipo de equipamento, frequência de uso e condições ambientais', 'Preço das peças e tempo de operação', 'Data de aquisição do equipamento e nível de eficiência', 'Modelo e marca do equipamento', 'alternativa_a'),
(17, 'Manutenção', 'Qual a diferença entre manutenção preventiva e manutenção preditiva?', 'A preventiva é programada, enquanto a preditiva é baseada em dados de monitoramento', 'A preventiva é realizada após falha, e a preditiva visa evitar falhas', 'A preditiva depende de manutenções periódicas, enquanto a preventiva é uma análise contínua', 'Não há diferença entre as duas', 'alternativa_a'),
(18, 'Manutenção', 'O que é a \"análise de falha\" na manutenção?', 'É a investigação das causas de falhas nos equipamentos para evitar recorrências', 'É a escolha dos equipamentos a serem substituídos', 'É a verificação do desempenho do equipamento após a manutenção', 'É a escolha dos melhores fornecedores de peças', 'alternativa_a'),
(19, 'Manutenção', 'O que é a \"manutenção de lubrificação\"?', 'É a manutenção realizada para garantir que as peças móveis funcionem corretamente', 'É a manutenção realizada após o uso excessivo do equipamento', 'É a verificação do sistema de resfriamento do equipamento', 'É a manutenção de ajuste de temperatura', 'alternativa_a'),
(20, 'Manutenção', 'O que é a \"manutenção de ajuste\"?', 'É o processo de garantir que o equipamento funcione de acordo com as especificações', 'É a manutenção relacionada a troca de peças desgastadas', 'É a verificação do software do equipamento', 'É a manutenção de limpeza', 'alternativa_a'),
(21, 'Manutenção', 'O que é considerado um fator de risco para falhas em hardwares de computadores?', 'Aquecimento excessivo causado por ventilação inadequada', 'Uso de softwares atualizados', 'Realização de backups periódicos', 'Troca de componentes sem necessidade', 'alternativa_a'),
(22, 'Manutenção', 'Quando a manutenção preventiva deve ser realizada em um servidor de arquivos?', 'Periodicamente, para evitar falhas no hardware e melhorar a performance', 'Somente quando o servidor apresentar problemas', 'Quando o servidor ficar mais de 30 dias sem ser utilizado', 'Somente ao trocar o sistema operacional', 'alternativa_a'),
(23, 'Manutenção', 'Qual é o primeiro passo na manutenção de impressoras laser?', 'Verificar se há papel preso no mecanismo e limpar os componentes internos', 'Trocar todos os cartuchos de tinta', 'Reinstalar o software da impressora', 'Reiniciar a impressora e verificar as conexões', 'alternativa_a'),
(24, 'Manutenção', 'O que é recomendado ao realizar a manutenção de um sistema de ar-condicionado de um servidor?', 'Limpar os filtros e verificar a temperatura interna para garantir eficiência no resfriamento', 'Substituir o sistema de ar-condicionado por um modelo mais recente', 'Ajustar o termostato para temperaturas mais altas', 'Desinstalar o ar-condicionado e usar ventiladores', 'alternativa_a'),
(25, 'Manutenção', 'Como deve ser feita a manutenção de baterias de dispositivos móveis?', 'Evitar que a bateria fique completamente descarregada por longos períodos e garantir o uso de carregadores originais', 'Carregar a bateria até o máximo sempre que possível', 'Trocar a bateria a cada 6 meses, mesmo sem sinais de falha', 'Deixar a bateria descarregar completamente antes de recarregar', 'alternativa_a'),
(26, 'Manutenção', 'O que deve ser feito quando um computador apresenta tela azul com erro do sistema operacional?', 'Anotar o código de erro, reiniciar o computador e verificar os logs do sistema para diagnosticar o problema', 'Formatar imediatamente o disco rígido', 'Reinstalar todos os drivers de hardware', 'Desinstalar todos os programas instalados recentemente', 'alternativa_a'),
(27, 'Manutenção', 'Qual é a principal diferença entre manutenção preventiva e corretiva?', 'A manutenção preventiva é realizada regularmente, enquanto a corretiva ocorre após uma falha', 'A manutenção preventiva é mais cara que a corretiva', 'A manutenção preventiva só pode ser feita durante a noite', 'A manutenção corretiva envolve mais peças que a preventiva', 'alternativa_a'),
(28, 'Manutenção', 'O que caracteriza a manutenção de hardware?', 'Troca de peças danificadas e ajustes no funcionamento físico do computador', 'Atualização de softwares e sistemas operacionais', 'Criação de novas configurações no sistema', 'Instalação de antivírus', 'alternativa_a'),
(29, 'Manutenção', 'Qual é o objetivo principal da manutenção de software?', 'Corrigir falhas e melhorar o desempenho do software', 'Trocar todos os programas para versões mais recentes', 'Excluir programas que estão funcionando bem', 'Instalar novos sistemas operacionais', 'alternativa_a'),
(30, 'Manutenção', 'O que é importante verificar ao fazer a manutenção de uma rede de computadores?', 'Certificar-se de que todos os cabos, switches e roteadores estão funcionando corretamente', 'Instalar todos os antivírus disponíveis', 'Alterar as senhas de todos os dispositivos na rede', 'Reinstalar todos os sistemas operacionais de cada computador', 'alternativa_a'),
(31, 'Manutenção', 'O que deve ser feito quando um computador apresenta superaquecimento?', 'Verificar se as ventoinhas estão funcionando corretamente e limpar o sistema de ventilação', 'Instalar mais memória RAM', 'Desinstalar programas pesados', 'Trocar o disco rígido', 'alternativa_a'),
(32, 'Eletrônica', 'O que é um resistor em um circuito eletrônico?', 'Um componente que limita o fluxo de corrente elétrica', 'Um dispositivo que armazena energia', 'Uma fonte de corrente elétrica', 'Um componente que amplifica sinais', 'alternativa_a'),
(33, 'Eletrônica', 'O que é a Lei de Ohm?', 'A relação entre tensão, corrente e resistência em um circuito', 'A lei que descreve a propagação de ondas eletromagnéticas', 'A equação que define a capacitância em circuitos RC', 'A relação entre a força e o campo magnético em um condutor', 'alternativa_a'),
(34, 'Eletrônica', 'O que é um diodo?', 'Um componente que permite a passagem de corrente em apenas uma direção', 'Um componente que amplifica a corrente elétrica', 'Um tipo de resistor variável', 'Um tipo de capacitor', 'alternativa_a'),
(35, 'Eletrônica', 'Qual é a principal função de um capacitor em um circuito?', 'Armazenar energia elétrica', 'Ampliar sinais de corrente', 'Reduzir a corrente elétrica', 'Proteger o circuito contra sobrecarga', 'alternativa_a'),
(36, 'Eletrônica', 'O que é um transistor?', 'Um componente que pode amplificar sinais elétricos', 'Uma resistência variável', 'Um componente que converte energia elétrica em mecânica', 'Um tipo de indutor', 'alternativa_a'),
(37, 'Eletrônica', 'O que é um circuito RC?', 'Um circuito que contém um resistor e um capacitor', 'Um circuito que contém um resistor e um transistor', 'Um circuito formado por um diodo e um transistor', 'Um circuito com múltiplos resistores em série', 'alternativa_a'),
(38, 'Eletrônica', 'O que é uma fonte de alimentação estabilizada?', 'Uma fonte que mantém uma tensão constante independentemente da carga', 'Uma fonte que converte corrente alternada em contínua', 'Uma fonte que regula a intensidade da corrente elétrica', 'Uma fonte que fornece altas tensões para circuitos industriais', 'alternativa_a'),
(39, 'Eletrônica', 'O que é a impedância?', 'A resistência total de um circuito em corrente alternada', 'A resistência de um circuito em corrente contínua', 'A capacidade de um circuito de armazenar energia', 'A taxa de variação de corrente em um circuito', 'alternativa_a'),
(40, 'Eletrônica', 'O que é um amplificador operacional?', 'Um dispositivo eletrônico usado para amplificar sinais de tensão', 'Um tipo de resistor', 'Um dispositivo que converte sinais digitais em analógicos', 'Um tipo de interruptor automático', 'alternativa_a'),
(41, 'Eletrônica', 'O que é um circuito LC?', 'Um circuito que contém um indutor e um capacitor', 'Um circuito que contém um resistor e um transistor', 'Um circuito de controle de corrente', 'Um circuito formado por um diodo e um resistor', 'alternativa_a'),
(42, 'Eletrônica', 'O que é a modulação de amplitude (AM)?', 'Uma técnica de modulação em que a amplitude de uma onda portadora é variada', 'Uma técnica de modulação onde a frequência de uma onda portadora é variada', 'A técnica de digitalização de um sinal', 'A conversão de um sinal analógico para digital', 'alternativa_a'),
(43, 'Eletrônica', 'O que é um indutor?', 'Um componente que armazena energia na forma de campo magnético', 'Um componente que armazena energia elétrica na forma de carga', 'Um tipo de resistor variável', 'Um componente que altera a direção da corrente elétrica', 'alternativa_a'),
(44, 'Eletrônica', 'O que é um osciloscópio?', 'Um equipamento utilizado para visualizar formas de onda elétricas', 'Um dispositivo que amplifica sinais de baixa frequência', 'Uma fonte de alimentação variável', 'Um medidor de temperatura elétrica', 'alternativa_a'),
(45, 'Eletrônica', 'O que é a frequência de ressonância em um circuito LC?', 'A frequência em que a impedância do circuito é mínima', 'A frequência em que a tensão no circuito é máxima', 'A frequência em que o circuito começa a dissipar energia', 'A frequência de funcionamento de um amplificador', 'alternativa_a'),
(46, 'Eletrônica', 'O que é a corrente alternada (CA)?', 'Uma corrente que alterna sua direção periodicamente', 'Uma corrente com intensidade constante ao longo do tempo', 'Uma corrente que só pode ser gerada por baterias', 'Uma corrente que circula apenas em circuitos fechados', 'alternativa_a'),
(47, 'Eletrônica', 'O que é a corrente contínua (CC)?', 'Uma corrente que flui em uma única direção', 'Uma corrente que alterna sua direção periodicamente', 'Uma corrente que é usada em circuitos de alta frequência', 'Uma corrente que é gerada por transformadores', 'alternativa_a'),
(48, 'Eletrônica', 'O que é um transformador?', 'Um dispositivo que altera a tensão de uma corrente elétrica', 'Um dispositivo que amplifica sinais de áudio', 'Um dispositivo que regula a corrente elétrica', 'Um tipo de resistor', 'alternativa_a'),
(49, 'Eletrônica', 'Qual é a função de um fusível em um circuito?', 'Proteger o circuito contra sobrecarga de corrente elétrica', 'Amplificar a corrente elétrica', 'Armazenar energia elétrica para uso posterior', 'Reduzir a resistência de um circuito', 'alternativa_a'),
(50, 'Eletrônica', 'O que é a indução magnética?', 'A criação de um campo magnético a partir de uma corrente elétrica', 'O processo de aumentar a corrente em um circuito', 'A mudança na direção de uma corrente elétrica', 'A alteração da frequência de um sinal elétrico', 'alternativa_a'),
(51, 'Eletrônica', 'O que é um circuito série?', 'Um circuito onde os componentes são conectados um após o outro', 'Um circuito com múltiplos caminhos para a corrente elétrica', 'Um circuito que utiliza apenas resistores', 'Um circuito com um único interruptor', 'alternativa_a'),
(52, 'Informática Básica', ' O que significa a sigla USB?', 'Universal Serial Bus (Barramento Serial Universal)', 'Unique Storage Bus (Barramento de Armazenamento Único)', 'Universal System Backup (Backup de Sistema Universal)', 'Unified Serial Bus (Barramento Serial Unificado)', 'alternativa_a'),
(53, 'Informática Básica', 'O que é um sistema operacional?', 'É o software que gerencia o hardware e o software do computador', 'É o programa de navegação na internet', 'É o programa que edita textos', 'É o aplicativo de e-mail', 'alternativa_a'),
(54, 'Informática Básica', 'Qual é a principal função de um processador?', 'Executar instruções e processar dados', 'Armazenar dados temporários', 'Exibir informações na tela', 'Proteger o computador contra vírus', 'alternativa_a'),
(55, 'Informática Básica', 'O que é a memória RAM?', 'Memória volátil utilizada para armazenar dados temporários', 'Memória permanente do computador', 'Memória que armazena o sistema operacional', 'Memória que armazena documentos e imagens', 'alternativa_a'),
(56, 'Informática Básica', 'O que é a unidade de processamento central (CPU)?', 'É o cérebro do computador, responsável por executar os processos', 'É um dispositivo de entrada de dados', 'É o dispositivo que armazena arquivos permanentemente', 'É um tipo de software para editar textos', 'alternativa_a'),
(57, 'Informática Básica', 'O que é o sistema operacional Windows?', 'É um sistema operacional desenvolvido pela Microsoft', 'É um tipo de antivírus', 'É um programa para criar apresentações', 'É um navegador de internet', 'alternativa_a'),
(58, 'Informática Básica', 'Qual é a função de um antivírus?', 'Proteger o computador contra malwares e vírus', 'Acelerar a execução de programas', 'Aumentar o volume do áudio', 'Monitorar o uso da internet', 'alternativa_a'),
(59, 'Informática Básica', 'O que é a navegação na internet?', 'É o processo de acessar e explorar páginas da web', 'É o processo de escrever textos no computador', 'É o processo de instalar programas', 'É o processo de gerenciar arquivos no computador', 'alternativa_a'),
(60, 'Informática Básica', 'O que é um navegador de internet?', 'É um software usado para acessar páginas web', 'É um programa para criar documentos de texto', 'É uma ferramenta para editar imagens', 'É um software para proteger o computador', 'alternativa_a'),
(61, 'Informática Básica', 'O que é a \"nuvem\" na informática?', 'É um sistema de armazenamento de dados online', 'É um tipo de vírus', 'É um software de edição de imagens', 'É um tipo de memória interna do computador', 'alternativa_a'),
(62, 'Informática Básica', 'Qual é a função do programa de edição de texto?', 'Criar, editar e formatar documentos de texto', 'Gerenciar redes sociais', 'Proteger o computador contra vírus', 'Fazer cálculos matemáticos', 'alternativa_a'),
(63, 'Informática Básica', 'O que é um arquivo?', 'É uma coleção de dados ou informações armazenadas em um dispositivo de armazenamento', 'É um programa que protege o computador', 'É um tipo de hardware do computador', 'É um vírus que danifica o computador', 'alternativa_a'),
(64, 'Informática Básica', 'O que é o \"Windows Explorer\"?', 'É o gerenciador de arquivos do sistema operacional Windows', 'É um software de navegação na internet', 'É o editor de texto do sistema operacional', 'É um programa de antivírus', 'alternativa_a'),
(65, 'Informática Básica', 'Qual é a função do processador gráfico (GPU)?', 'Processar imagens e vídeos', 'Armazenar dados temporários', 'Controlar as interações do teclado', 'Gerenciar a navegação na internet', 'alternativa_a'),
(66, 'Informática Básica', 'O que é um backup?', 'Uma cópia de segurança dos dados', 'Um tipo de vírus', 'Uma atualização do sistema operacional', 'Um programa de edição de fotos', 'alternativa_a'),
(67, 'Informática Básica', 'O que é um sistema de arquivos?', 'É a estrutura utilizada para organizar e armazenar arquivos em um dispositivo de armazenamento', 'É um software antivírus', 'É o tipo de memória do computador', 'É o nome de um programa de navegação', 'alternativa_a'),
(68, 'Informática Básica', 'O que é um \"cookie\" na internet?', 'São pequenos arquivos armazenados no navegador que guardam preferências e informações do usuário', 'É um tipo de vírus', 'É uma ferramenta para aumentar a velocidade de navegação', 'É um tipo de memória do computador', 'alternativa_a'),
(69, 'Informática Básica', 'O que é um \"link\" em uma página da web?', 'É um endereço que permite acessar outra página ou recurso na internet', 'É um tipo de arquivo de imagem', 'É um programa antivírus', 'É um tipo de memória RAM', 'alternativa_a'),
(70, 'Informática Básica', 'O que significa a sigla Wi-Fi?', 'Wireless Fidelity (Fidelidade Sem Fio)', 'World Internet Function (Função Mundial da Internet)', 'Wireless Internet Frequency (Frequência de Internet Sem Fio)', 'Wide Internet Fidelity (Fidelidade de Internet Larga)', 'alternativa_a'),
(71, 'Informática Básica', 'O que é um \"byte\"?', 'Uma unidade de armazenamento que representa 8 bits', 'Uma unidade de processamento do computador', 'Um tipo de vírus', 'Uma unidade de memória RAM', 'alternativa_a'),
(72, 'Fundamentos de Lógica e Algoritmos', 'O que é um algoritmo?', 'Um conjunto de instruções para resolver um problema', 'Uma linguagem de programação', 'Uma estrutura de dados', 'Uma ferramenta para editar programas', 'alternativa_a'),
(73, 'Fundamentos de Lógica e Algoritmos', 'Qual é a principal característica de um algoritmo?', 'Ele deve ser finito e bem definido', 'Deve ser executado em tempo infinito', 'Deve ser escrito em uma linguagem de programação', 'Deve ser executado apenas uma vez', 'alternativa_a'),
(74, 'Fundamentos de Lógica e Algoritmos', 'O que significa a palavra \"sequência\" em lógica de algoritmos?', 'A execução de instruções em uma ordem específica', 'A repetição de um conjunto de comandos', 'A tomada de decisões condicionais', 'A manipulação de dados em tabelas', 'alternativa_a'),
(75, 'Fundamentos de Lógica e Algoritmos', 'O que é uma estrutura condicional?', 'Uma sequência de comandos que são executados repetidamente', 'Uma estrutura que permite executar comandos dependendo de uma condição', 'Uma maneira de organizar dados em uma tabela', 'Uma forma de organizar funções em um algoritmo', 'alternativa_b'),
(76, 'Fundamentos de Lógica e Algoritmos', 'Qual é a estrutura de repetição mais comum em algoritmos?', 'Se...Senão', 'Para...Enquanto', 'Enquanto...Faca', 'Repita...Até', 'alternativa_c'),
(77, 'Fundamentos de Lógica e Algoritmos', 'O que é um pseudocódigo?', 'Uma forma de código executável', 'Uma linguagem de programação', 'Uma representação do algoritmo em linguagem natural', 'Um tipo de sistema operacional', 'alternativa_c'),
(78, 'Fundamentos de Lógica e Algoritmos', 'O que significa a palavra-chave \"return\" em um algoritmo?', 'Indica o fim do algoritmo', 'Retorna um valor para a função ou processo que a chamou', 'Faz uma comparação de valores', 'Inicia um novo algoritmo', 'alternativa_b'),
(79, 'Fundamentos de Lógica e Algoritmos', 'Em um diagrama de fluxo, o que simboliza o losango?', 'Início do algoritmo', 'Saída de dados', 'Decisão condicional', 'Processo de repetição', 'alternativa_c'),
(80, 'Fundamentos de Lógica e Algoritmos', 'Qual a principal função de uma variável em um algoritmo?', 'Armazenar dados temporários durante a execução', 'Fazer comparações', 'Exibir resultados para o usuário', 'Replicar operações', 'alternativa_a'),
(81, 'Fundamentos de Lógica e Algoritmos', 'Qual é a ordem correta de execução de um algoritmo básico?', 'Entrada, Processamento, Saída', 'Saída, Entrada, Processamento', 'Processamento, Entrada, Saída', 'Entrada, Saída, Processamento', 'alternativa_a'),
(82, 'Fundamentos de Lógica e Algoritmos', 'O que é uma função recursiva?', 'Uma função que chama a si mesma', 'Uma função que executa um loop', 'Uma função que realiza comparações de dados', 'Uma função que retorna valores matemáticos', 'alternativa_a'),
(83, 'Fundamentos de Lógica e Algoritmos', 'O que é a notação Big O?', 'Uma medida de tempo de execução de um algoritmo', 'Uma estrutura de dados', 'Uma técnica de ordenação', 'Uma ferramenta de programação', 'alternativa_a'),
(84, 'Fundamentos de Lógica e Algoritmos', 'O que significa a notação O(1) em complexidade algorítmica?', 'O algoritmo tem um tempo de execução constante', 'O algoritmo aumenta seu tempo de execução de forma linear', 'O algoritmo tem um tempo de execução proporcional ao número de dados', 'O algoritmo aumenta seu tempo de execução exponencialmente', 'alternativa_a'),
(85, 'Fundamentos de Lógica e Algoritmos', 'Qual é a função de um loop?', 'Executar uma sequência de comandos repetidamente até uma condição ser satisfeita', 'Armazenar valores em uma lista', 'Comparar dois valores', 'Criar uma variável temporária', 'alternativa_a'),
(86, 'Fundamentos de Lógica e Algoritmos', 'O que significa a estrutura \"Se...Senão\"?', 'Executa um bloco de código dependendo de uma condição', 'Repete um bloco de código enquanto uma condição for verdadeira', 'Atribui um valor a uma variável', 'Executa um código quando um loop termina', 'alternativa_a'),
(87, 'Fundamentos de Lógica e Algoritmos', 'Em qual dos casos um algoritmo de ordenação é mais útil?', 'Quando você precisa ordenar uma lista de itens', 'Quando você precisa calcular um valor médio', 'Quando você precisa realizar uma comparação entre dois números', 'Quando você precisa armazenar dados', 'alternativa_a'),
(88, 'Fundamentos de Lógica e Algoritmos', 'O que é a técnica de \"dividir para conquistar\"?', 'Uma estratégia de dividir um problema em subproblemas menores', 'Uma técnica de repetição de código', 'Uma forma de otimizar a leitura de dados', 'Uma maneira de manipular arrays', 'alternativa_a'),
(89, 'Fundamentos de Lógica e Algoritmos', 'O que é uma estrutura de dados do tipo pilha?', 'Uma estrutura onde o último elemento inserido é o primeiro a ser removido', 'Uma estrutura onde os elementos são removidos em qualquer ordem', 'Uma estrutura que armazena elementos de forma ordenada', 'Uma estrutura onde o primeiro elemento inserido é o primeiro a ser removido', 'alternativa_a'),
(90, 'Fundamentos de Lógica e Algoritmos', 'O que é a recursão em um algoritmo?', 'O processo de um algoritmo chamar a si mesmo', 'A execução de um código em um loop', 'A comparação de valores em uma lista', 'A criação de uma variável temporária', 'alternativa_a'),
(91, 'Fundamentos de Lógica e Algoritmos', 'Qual é a principal vantagem do uso de algoritmos eficientes?', 'Reduzir o tempo de execução e o uso de recursos', 'Aumentar a complexidade do código', 'Facilitar a escrita do código', 'Aumentar o consumo de memória', 'alternativa_a'),
(92, 'Desenvolvimento de Software', 'O que significa a sigla OOP?', 'Organização de Objetos Processuais', 'Orientação a Objetos de Programação', 'Operações Orientadas a Parâmetros', 'Objetos de Operações de Programação', 'alternativa_b'),
(93, 'Desenvolvimento de Software', 'Qual dessas é uma característica do método ágil de desenvolvimento de software?', 'Documentação extensa', 'Entrega contínua de funcionalidades', 'Desenvolvimento linear e sequencial', 'Desenvolvimento apenas em grandes equipes', 'alternativa_b'),
(94, 'Desenvolvimento de Software', 'Qual a função de um repositório no Git?', 'Armazenar o código-fonte do projeto e seu histórico de alterações', 'Executar o código do projeto', 'Controlar os processos de teste do software', 'Gerenciar as tarefas do projeto', 'alternativa_a'),
(95, 'Desenvolvimento de Software', 'O que é um algoritmo?', 'Uma sequência de passos para resolver um problema', 'Uma linguagem de programação', 'Uma ferramenta de desenvolvimento', 'Um tipo de estrutura de dados', 'alternativa_a'),
(96, 'Desenvolvimento de Software', 'O que é a refatoração no desenvolvimento de software?', 'Melhorar a performance do código sem alterar sua funcionalidade', 'Adicionar novas funcionalidades ao software', 'Remover funcionalidades obsoletas do software', 'Documentar o código para facilitar a manutenção', 'alternativa_a'),
(97, 'Desenvolvimento de Software', 'O que é um teste unitário?', 'Teste de integração de diferentes sistemas', 'Teste realizado para verificar a unidade de código, como funções ou métodos', 'Teste de usabilidade do software', 'Teste de segurança de rede', 'alternativa_b'),
(98, 'Desenvolvimento de Software', 'O que é uma API (Interface de Programação de Aplicações)?', 'Uma interface gráfica para o usuário', 'Um sistema de controle de versão', 'Conjunto de funções que permite a comunicação entre diferentes sistemas ou componentes', 'Uma biblioteca de funções para redes', 'alternativa_c'),
(99, 'Desenvolvimento de Software', 'O que é o conceito de \"clean code\"?', 'Escrever código de forma limpa e eficiente, fácil de entender e manter', 'Escrever código com o mínimo possível de comentários', 'Utilizar a menor quantidade de linhas de código possível', 'Escrever código que só funcione no ambiente de desenvolvimento', 'alternativa_a'),
(100, 'Desenvolvimento de Software', 'O que é um banco de dados relacional?', 'Um banco de dados que armazena dados em tabelas relacionadas', 'Um banco de dados baseado em arquivos de texto', 'Um sistema de gerenciamento de código-fonte', 'Uma ferramenta para visualização de dados', 'alternativa_a'),
(101, 'Desenvolvimento de Software', 'O que é a metodologia Scrum?', 'Um tipo de banco de dados', 'Uma metodologia ágil de desenvolvimento de software', 'Um framework de testes de software', 'Um sistema de controle de versão', 'alternativa_b'),
(102, 'Desenvolvimento de Software', 'Qual dessas linguagens é mais comumente usada para desenvolvimento web?', 'Java', 'Python', 'JavaScript', 'C', 'alternativa_c'),
(103, 'Desenvolvimento de Software', 'O que é a integração contínua (CI)?', 'Uma prática de integrar mudanças no código de forma contínua e frequente', 'Uma metodologia de desenvolvimento de software', 'Uma ferramenta de gerenciamento de projetos', 'Uma linguagem de programação', 'alternativa_a'),
(104, 'Desenvolvimento de Software', 'Qual é a principal função do Git no desenvolvimento de software?', 'Armazenar o código em uma nuvem', 'Controle de versões e colaboração no código', 'Executar o código diretamente', 'Gerenciar os testes do software', 'alternativa_b'),
(105, 'Desenvolvimento de Software', 'O que significa a sigla CI/CD?', 'Configuração Integrada/Desenvolvimento Contínuo', 'Integração Contínua/Entrega Contínua', 'Controle de Integração/Desenvolvimento Contínuo', 'Códigos Integrados/Desenvolvimento de Software', 'alternativa_b'),
(106, 'Desenvolvimento de Software', 'O que é a técnica de TDD (Test-Driven Development)?', 'Desenvolver software sem testes', 'Escrever os testes antes de desenvolver o código', 'Testar o software depois de concluído', 'Testar em produção', 'alternativa_b'),
(107, 'Desenvolvimento de Software', 'Qual dessas ferramentas é usada para versionamento de código?', 'Git', 'Docker', 'Jenkins', 'MySQL', 'alternativa_a'),
(108, 'Desenvolvimento de Software', 'O que é uma variável em programação?', 'Uma função que armazena valores temporariamente', 'Uma estrutura de dados que contém informações', 'Uma caixa de armazenamento para valores', 'Uma forma de dividir o código em módulos', 'alternativa_c'),
(109, 'Desenvolvimento de Software', 'Qual dessas é uma linguagem de programação orientada a objetos?', 'C', 'Java', 'HTML', 'CSS', 'alternativa_b'),
(110, 'Desenvolvimento de Software', 'O que é o conceito de \"debugging\"?', 'O processo de otimizar o código', 'O processo de encontrar e corrigir erros no código', 'O processo de testar a segurança do software', 'O processo de refatoração do código', 'alternativa_b'),
(111, 'Autoria Web', 'O que é HTML?', 'Uma linguagem de marcação usada para criar a estrutura de páginas web', 'Uma linguagem de programação usada para cálculos matemáticos', 'Uma biblioteca de JavaScript para manipular o DOM', 'Um software para desenvolvimento de aplicativos', 'alternativa_a'),
(113, 'Autoria Web', 'O que significa CSS?', 'Cascading Style Sheets', 'Computer Style System', 'Coding Standard Syntax', 'Color Styling Sheets', 'alternativa_a'),
(114, 'Autoria Web', 'Para que serve o CSS?', 'Estilizar o layout de páginas web', 'Criar a estrutura básica de um site', 'Conectar um banco de dados ao site', 'Gerar gráficos para páginas web', 'alternativa_a'),
(115, 'Autoria Web', 'Qual é o uso da tag <head> em HTML?', 'Armazenar metadados e links para recursos externos', 'Definir o conteúdo principal da página', 'Adicionar scripts JavaScript interativos', 'Criar tabelas no layout', 'alternativa_a'),
(116, 'Autoria Web', 'O que é JavaScript?', 'Uma linguagem de programação para adicionar interatividade às páginas web', 'Uma linguagem de marcação como HTML', 'Uma ferramenta para estilização de páginas web', 'Um editor de texto para programação', 'alternativa_a'),
(117, 'Autoria Web', 'Qual é a função da tag <img> em HTML?', 'Adicionar imagens a uma página web', 'Inserir vídeos na página', 'Criar animações no site', 'Conectar arquivos de áudio', 'alternativa_a'),
(118, 'Autoria Web', 'O que é uma tag semântica em HTML?', 'Uma tag que descreve claramente o propósito de seu conteúdo', 'Uma tag usada apenas para estilização', 'Uma tag que contém apenas scripts', 'Uma tag que define cabeçalhos de tabelas', 'alternativa_a'),
(119, 'Autoria Web', 'Qual é a diferença entre classes e IDs no CSS?', 'IDs são únicos e aplicados a um elemento, enquanto classes podem ser reutilizadas em vários elementos', 'Classes são únicas e IDs podem ser reutilizados', 'IDs são usados apenas em JavaScript', 'Classes são usadas para conexões com bancos de dados', 'alternativa_a'),
(120, 'Autoria Web', 'Para que serve a tag <a> em HTML?', 'Criar links para outras páginas ou recursos', 'Adicionar imagens a uma página', 'Definir parágrafos de texto', 'Estilizar elementos de texto', 'alternativa_a'),
(121, 'Autoria Web', 'Qual é o uso da tag <title> no HTML?', 'Definir o título que aparece na aba do navegador', 'Adicionar títulos às imagens', 'Criar cabeçalhos em tabelas', 'Estilizar o texto principal', 'alternativa_a'),
(122, 'Autoria Web', 'Qual é o atributo usado para adicionar um link em uma tag <a>?', 'href', 'src', 'link', 'alt', 'alternativa_a'),
(123, 'Autoria Web', 'O que o atributo \"alt\" em uma tag <img> faz?', 'Define um texto alternativo caso a imagem não carregue', 'Estiliza a imagem', 'Define o alinhamento da imagem', 'Adiciona uma borda à imagem', 'alternativa_a'),
(124, 'Autoria Web', 'Qual é a função do JavaScript no desenvolvimento web?', 'Adicionar interatividade e funcionalidades dinâmicas às páginas web', 'Criar a estrutura básica da página', 'Estilizar elementos do site', 'Gerar arquivos de imagens automaticamente', 'alternativa_a'),
(125, 'Autoria Web', 'O que é o DOM em JavaScript?', 'Uma representação em árvore da estrutura de um documento HTML ou XML', 'Um banco de dados para armazenar dados da página', 'Uma ferramenta para estilizar elementos', 'Uma extensão para criar tabelas dinâmicas', 'alternativa_a'),
(126, 'Autoria Web', 'Qual é o propósito da propriedade \"color\" no CSS?', 'Alterar a cor do texto', 'Alterar a cor do fundo', 'Definir margens entre elementos', 'Adicionar efeitos de animação', 'alternativa_a'),
(127, 'Autoria Web', 'Qual é o elemento correto para criar uma lista não ordenada no HTML?', '<ul>', '<ol>', '<li>', '<list>', 'alternativa_a'),
(128, 'Autoria Web', 'Para que serve a tag <footer> em HTML?', 'Definir a seção de rodapé de uma página', 'Adicionar cabeçalhos ao conteúdo', 'Criar parágrafos com estilo especial', 'Inserir tabelas no final de um documento', 'alternativa_a'),
(129, 'Autoria Web', 'Qual é a propriedade CSS usada para centralizar texto dentro de um elemento?', 'text-align: center;', 'align-content: center;', 'justify-content: center;', 'center-text: true;', 'alternativa_a'),
(130, 'Autoria Web', 'O que é um seletor no CSS?', 'Uma maneira de selecionar elementos HTML para aplicar estilos', 'Uma função usada para calcular valores', 'Um atributo de uma tag HTML', 'Uma propriedade para definir tamanhos', 'alternativa_a'),
(131, 'Banco de Dados', 'O que é um banco de dados?', 'Um sistema de armazenamento físico de dados em papel', 'Um conjunto de dados organizados de forma a permitir a manipulação eficiente', 'Um programa para criação de gráficos de dados', 'Um tipo de servidor para armazenamento de dados temporários', 'alternativa_b'),
(132, 'Banco de Dados', 'O que é uma chave primária em um banco de dados?', 'Um campo ou conjunto de campos que identifica exclusivamente cada registro na tabela', 'Uma chave usada para criptografar os dados do banco de dados', 'Uma chave que define o tipo de dados a ser armazenado', 'Um campo que pode ter valores duplicados em uma tabela', 'alternativa_a'),
(133, 'Banco de Dados', 'Qual comando SQL é usado para recuperar dados de uma tabela?', 'INSERT', 'UPDATE', 'DELETE', 'SELECT', 'alternativa_d'),
(134, 'Banco de Dados', 'O que é uma tabela em um banco de dados?', 'Uma forma de classificar diferentes tipos de dados no banco', 'Uma coleção de dados organizados em linhas e colunas', 'Um tipo de backup de dados', 'Uma interface gráfica para interação com o banco de dados', 'alternativa_b'),
(135, 'Banco de Dados', 'O que é uma chave estrangeira em um banco de dados?', 'Um campo em uma tabela que faz referência a uma chave primária em outra tabela', 'Uma chave usada para criptografar dados', 'Um campo de uma tabela que não pode ter valores nulos', 'Uma chave que define a integridade referencial do banco de dados', 'alternativa_a'),
(136, 'Banco de Dados', 'O que é normalização de banco de dados?', 'O processo de remover redundâncias e dependências nos dados', 'O processo de garantir a segurança dos dados', 'O processo de criptografar os dados armazenados', 'O processo de restaurar dados de um backup', 'alternativa_a'),
(137, 'Banco de Dados', 'O que é um índice em banco de dados?', 'Uma estrutura de dados que melhora a velocidade das operações de consulta', 'Uma tabela que contém dados históricos', 'Um tipo de chave primária alternativa', 'Uma estratégia de backup de dados', 'alternativa_a'),
(138, 'Banco de Dados', 'O que é SQL?', 'Uma linguagem de consulta estruturada usada para gerenciar bancos de dados relacionais', 'Um sistema de backup para bancos de dados', 'Uma ferramenta de visualização de dados', 'Uma linguagem de programação para criação de aplicativos', 'alternativa_a'),
(139, 'Banco de Dados', 'O que significa DDL em SQL?', 'Data Definition Language', 'Data Development Language', 'Data Deletion Language', 'Data Delivery Language', 'alternativa_a'),
(140, 'Banco de Dados', 'O que significa o comando SQL INSERT?', 'Adicionar novos dados a uma tabela', 'Atualizar os dados existentes de uma tabela', 'Remover dados de uma tabela', 'Criar uma nova tabela no banco de dados', 'alternativa_a'),
(141, 'Banco de Dados', 'Qual é a função do comando SQL UPDATE?', 'Atualizar os dados existentes em uma tabela', 'Inserir novos dados em uma tabela', 'Remover dados de uma tabela', 'Alterar a estrutura de uma tabela', 'alternativa_a'),
(142, 'Banco de Dados', 'O que é um banco de dados relacional?', 'Um banco de dados que armazena dados em tabelas relacionadas entre si', 'Um banco de dados que armazena dados em arquivos planos', 'Um banco de dados que armazena dados como objetos', 'Um banco de dados sem a necessidade de tabelas ou relacionamentos', 'alternativa_a'),
(143, 'Banco de Dados', 'O que significa a sigla ACID em banco de dados?', 'Atomicidade, Consistência, Isolamento e Durabilidade', 'Algoritmo de Criptografia e Integração de Dados', 'Análise de Consistência e Identificação de Dados', 'Arquitetura de Criação e Integração de Dados', 'alternativa_a'),
(144, 'Banco de Dados', 'O que é uma transação em banco de dados?', 'Uma sequência de operações que devem ser tratadas como uma unidade atômica', 'Uma operação que altera a estrutura de uma tabela', 'Uma consulta SQL que obtém dados de várias tabelas', 'Uma técnica de backup de dados', 'alternativa_a'),
(145, 'Banco de Dados', 'O que é o comando SQL DELETE?', 'Adicionar novos dados a uma tabela', 'Atualizar os dados existentes de uma tabela', 'Criar uma nova tabela', 'Remover dados de uma tabela', 'alternativa_d'),
(146, 'Banco de Dados', 'O que é uma subconsulta em SQL?', 'Uma consulta dentro de outra consulta', 'Uma consulta que retorna todos os registros de uma tabela', 'Uma consulta que altera os dados de uma tabela', 'Uma consulta que retorna apenas uma linha de dados', 'alternativa_a'),
(147, 'Banco de Dados', 'O que é a normalização em banco de dados?', 'O processo de organizar os dados para minimizar a redundância', 'O processo de segurança de dados', 'O processo de backup de dados', 'O processo de criar índices para melhorar a consulta', 'alternativa_a'),
(148, 'Banco de Dados', 'O que é uma relação em um banco de dados relacional?', 'Uma tabela que contém dados relacionados entre si', 'A conexão entre duas tabelas que compartilham dados comuns', 'Um campo que pode ser duplicado em tabelas diferentes', 'Uma chave primária que relaciona dados em tabelas diferentes', 'alternativa_b'),
(149, 'Banco de Dados', 'O que é um banco de dados NoSQL?', 'Um banco de dados que não usa a estrutura de tabelas relacionais', 'Um banco de dados que armazena apenas dados textuais', 'Um banco de dados utilizado para armazenar dados em formato XML', 'Um banco de dados baseado em arquivos CSV', 'alternativa_a'),
(150, 'Banco de Dados', 'O que é uma view (visão) em banco de dados?', 'Uma consulta armazenada que pode ser tratada como uma tabela', 'Uma tabela temporária usada para armazenar dados', 'Um tipo de campo que armazena dados de várias tabelas', 'Uma técnica de backup de dados', 'alternativa_a'),
(151, 'Programação Estruturada e Orientada a Objetos', 'O que caracteriza a programação orientada a objetos?', 'A divisão do código em classes e objetos para modelar entidades do mundo real', 'A escrita de código sequencial sem a utilização de estruturas como classes', 'O uso de algoritmos simples para resolver problemas', 'A utilização de uma única variável global no código', 'alternativa_a'),
(152, 'Programação Estruturada e Orientada a Objetos', 'Qual é o conceito de \"classe\" em POO?', 'Uma descrição abstrata de um conjunto de objetos com características e comportamentos comuns', 'Uma variável que armazena valores temporários', 'Uma função que manipula dados', 'Uma estrutura de controle condicional', 'alternativa_a'),
(153, 'Programação Estruturada e Orientada a Objetos', 'O que é um objeto em POO?', 'Uma instância de uma classe que possui atributos e métodos', 'Uma variável que armazena um tipo de dado específico', 'Uma estrutura de repetição em um programa', 'Uma função que realiza cálculos', 'alternativa_a'),
(154, 'Programação Estruturada e Orientada a Objetos', 'O que é encapsulamento em POO?', 'A prática de ocultar os detalhes internos de uma classe e expor apenas o que for necessário', 'A criação de novas instâncias de uma classe', 'A habilidade de uma classe herdar atributos e métodos de outra', 'A utilização de loops para manipulação de dados', 'alternativa_a'),
(155, 'Programação Estruturada e Orientada a Objetos', 'O que é herança em POO?', 'A capacidade de uma classe herdar características de outra', 'A criação de novas instâncias de um objeto', 'A modificação de métodos existentes', 'A união de várias classes em um único objeto', 'alternativa_a'),
(156, 'Programação Estruturada e Orientada a Objetos', 'O que é polimorfismo em POO?', 'A habilidade de um objeto assumir diferentes formas, geralmente por meio de sobrescrita ou sobrecarga de métodos', 'A criação de classes que não possuem atributos ou métodos', 'A declaração de variáveis dentro de métodos', 'O armazenamento de dados de forma externa ao programa', 'alternativa_a'),
(157, 'Programação Estruturada e Orientada a Objetos', 'O que significa abstração em POO?', 'A habilidade de representar entidades do mundo real sem mostrar todos os detalhes', 'A utilização de funções sem a necessidade de parâmetros', 'A criação de múltiplas instâncias da mesma classe', 'O uso de variáveis globais para compartilhar dados entre métodos', 'alternativa_a'),
(158, 'Programação Estruturada e Orientada a Objetos', 'O que é um construtor em uma classe?', 'Um método especial utilizado para inicializar um objeto quando ele é criado', 'Uma variável que armazena um valor fixo', 'Uma função que calcula valores baseados em entradas do usuário', 'Uma função que destrói um objeto após o uso', 'alternativa_a'),
(159, 'Programação Estruturada e Orientada a Objetos', 'O que é um destruidor em uma classe?', 'Um método especial que é chamado quando um objeto é destruído ou liberado da memória', 'Uma função que armazena os dados de um objeto em um arquivo', 'Um tipo de variável usado para rastrear o número de instâncias de uma classe', 'Uma função que retorna valores de um objeto para o usuário', 'alternativa_a'),
(160, 'Programação Estruturada e Orientada a Objetos', 'O que é um método em POO?', 'Uma função que define o comportamento de um objeto', 'Uma variável que armazena informações sobre um objeto', 'Uma estrutura de controle usada dentro de classes', 'Uma função que apenas imprime informações na tela', 'alternativa_a'),
(161, 'Programação Estruturada e Orientada a Objetos', 'O que significa a palavra-chave \"this\" em POO?', 'Refere-se à instância atual de um objeto dentro de seus métodos', 'Refere-se a uma variável global dentro de uma classe', 'Refere-se a uma função chamada dentro da própria classe', 'Refere-se a um objeto estático', 'alternativa_a'),
(162, 'Programação Estruturada e Orientada a Objetos', 'O que é um modificador de acesso em POO?', 'Define a visibilidade de atributos e métodos dentro de uma classe', 'Define o tipo de dados que um objeto pode armazenar', 'Especifica a quantidade de memória necessária para um objeto', 'Define o tempo de vida de um objeto dentro de um programa', 'alternativa_a'),
(163, 'Programação Estruturada e Orientada a Objetos', 'O que é a visibilidade \"public\" em POO?', 'Os atributos e métodos são acessíveis de qualquer lugar', 'Os atributos e métodos só são acessíveis dentro da própria classe', 'Os atributos e métodos só são acessíveis nas subclasses', 'Os atributos e métodos não podem ser acessados diretamente', 'alternativa_a'),
(164, 'Programação Estruturada e Orientada a Objetos', 'O que é a visibilidade \"private\" em POO?', 'Os atributos e métodos só são acessíveis dentro da própria classe', 'Os atributos e métodos são acessíveis de qualquer lugar', 'Os atributos e métodos só podem ser acessados nas subclasses', 'Os atributos e métodos não têm visibilidade no código', 'alternativa_a'),
(165, 'Programação Estruturada e Orientada a Objetos', 'O que é a visibilidade \"protected\" em POO?', 'Os atributos e métodos são acessíveis dentro da classe e nas subclasses', 'Os atributos e métodos são acessíveis de qualquer lugar', 'Os atributos e métodos só podem ser acessados dentro da própria classe', 'Os atributos e métodos não podem ser modificados', 'alternativa_a'),
(166, 'Programação Estruturada e Orientada a Objetos', 'O que é uma interface em POO?', 'Um contrato que define um conjunto de métodos que uma classe deve implementar', 'Uma classe que contém apenas atributos e sem métodos', 'Uma função que executa todas as operações de entrada e saída', 'Uma forma de herança múltipla entre classes', 'alternativa_a'),
(167, 'Programação Estruturada e Orientada a Objetos', 'O que é uma classe abstrata?', 'Uma classe que não pode ser instanciada diretamente, servindo como base para outras classes', 'Uma classe que contém apenas métodos e sem atributos', 'Uma classe que pode ser instanciada sem restrições', 'Uma classe que tem todos os seus métodos implementados', 'alternativa_a'),
(168, 'Programação Estruturada e Orientada a Objetos', 'O que é um método estático?', 'Um método que pertence à classe e não a uma instância específica', 'Um método que só pode ser chamado dentro de outra função', 'Um método que manipula apenas atributos locais da classe', 'Um método que pode ser acessado apenas de fora da classe', 'alternativa_a'),
(169, 'Programação Estruturada e Orientada a Objetos', 'Qual a diferença entre sobrecarga de método e sobrescrita de método?', 'Sobrecarga de método envolve a criação de métodos com o mesmo nome mas parâmetros diferentes, enquanto sobrescrita envolve redefinir o comportamento de um método herdado', 'Sobrecarga de método envolve mudar o nome do método, enquanto sobrescrita muda apenas o tipo de dado', 'Sobrecarga e sobrescrita são a mesma coisa em POO', 'Sobrecarga e sobrescrita envolvem apenas a alteração de variáveis', 'alternativa_a'),
(170, 'Programação Estruturada e Orientada a Objetos', 'O que é um construtor de cópia?', 'Um construtor especial que cria uma cópia de um objeto', 'Uma função que cria um objeto a partir de parâmetros fornecidos pelo usuário', 'Uma função que inicializa atributos de uma classe', 'Uma função que destrói objetos', 'alternativa_a'),
(171, 'Arquitetura de Rede de Computadores', 'O que é uma rede de computadores?', 'Conjunto de servidores interconectados em uma empresa', 'Dispositivo que conecta diferentes redes de computadores', 'Conjunto de dispositivos interconectados para compartilhar recursos e dados', 'Grupo de sistemas operacionais que se comunicam entre si', 'alternativa_c'),
(172, 'Arquitetura de Rede de Computadores', 'O que é um protocolo de comunicação?', 'Um tipo de software utilizado para gerenciar redes de computadores', 'Um dispositivo que transmite sinais de dados em uma rede', 'A parte física que conecta os dispositivos em uma rede', 'Um conjunto de regras que define como os dispositivos trocam dados em uma rede', 'alternativa_d'),
(173, 'Arquitetura de Rede de Computadores', 'O que é o modelo OSI?', 'Um sistema operacional utilizado para gerenciamento de redes', 'Uma rede de computadores local', 'Um modelo de referência que descreve as camadas de comunicação em redes de computadores', 'Um tipo de protocolo usado para transmitir dados', 'alternativa_c'),
(174, 'Arquitetura de Rede de Computadores', 'Qual camada do modelo OSI é responsável pela comunicação de dados entre dispositivos finais?', 'Camada de Enlace de Dados', 'Camada de Rede', 'Camada de Aplicação', 'Camada de Transporte', 'alternativa_d'),
(175, 'Arquitetura de Rede de Computadores', 'O que é um endereço IP?', 'Um protocolo de comunicação', 'O nome de um servidor de rede', 'Uma chave de segurança usada em redes wireless', 'Um identificador único para dispositivos em uma rede', 'alternativa_d'),
(176, 'Arquitetura de Rede de Computadores', 'O que é uma máscara de sub-rede?', 'Um protocolo de segurança de rede', 'Um valor usado para dividir redes IP em sub-redes menores', 'Um tipo de rede sem fio', 'Um endereço utilizado para configurar um roteador', 'alternativa_b'),
(177, 'Arquitetura de Rede de Computadores', 'O que é um roteador?', 'Equipamento de segurança que filtra tráfego de rede', 'Dispositivo responsável por encaminhar pacotes entre redes diferentes', 'Dispositivo que conecta os dispositivos a uma rede sem fio', 'Dispositivo usado para armazenar dados em uma rede', 'alternativa_b');
INSERT INTO `questoes` (`id`, `disciplina`, `enunciado`, `alternativa_a`, `alternativa_b`, `alternativa_c`, `alternativa_d`, `resposta_correta`) VALUES
(178, 'Arquitetura de Rede de Computadores', 'O que é o protocolo TCP/IP?', 'Protocolo de controle de tráfego de rede', 'Conjunto de protocolos de comunicação usados na internet e redes privadas', 'Protocolo de configuração de endereços IP', 'Protocolo de segurança para redes sem fio', 'alternativa_b'),
(179, 'Arquitetura de Rede de Computadores', 'Qual é a função da camada de enlace de dados no modelo OSI?', 'Estabelecer e manter uma conexão lógica entre dispositivos', 'Transmissão física de dados entre os dispositivos', 'Controlar o fluxo de dados e garantir a integridade da comunicação', 'Roteamento de pacotes entre redes diferentes', 'alternativa_c'),
(180, 'Arquitetura de Rede de Computadores', 'O que é a camada física no modelo OSI?', 'Responsável pelo gerenciamento de pacotes de dados', 'Responsável pelo controle de erros na comunicação', 'Responsável pela transmissão de dados em forma de sinais elétricos ou ópticos', 'Responsável pela criptografia dos dados', 'alternativa_c'),
(181, 'Arquitetura de Rede de Computadores', 'O que é um switch?', 'Equipamento utilizado para criar redes sem fio', 'Dispositivo que gerencia endereços IP em uma rede', 'Dispositivo que conecta múltiplos dispositivos dentro de uma mesma rede local', 'Dispositivo que realiza o roteamento de pacotes entre diferentes redes', 'alternativa_c'),
(182, 'Arquitetura de Rede de Computadores', 'O que é a VLAN?', 'Uma rede virtual que isola e segmenta dispositivos dentro de uma rede física', 'Um tipo de roteador de rede', 'Um endereço IP específico para comunicação entre dispositivos', 'Uma camada de segurança em redes de computadores', 'alternativa_a'),
(183, 'Arquitetura de Rede de Computadores', 'O que é o protocolo HTTP?', 'Protocolo de comunicação em tempo real', 'Protocolo para configurar redes locais', 'Protocolo usado para transferir páginas web na internet', 'Protocolo de segurança para redes sem fio', 'alternativa_c'),
(184, 'Arquitetura de Rede de Computadores', 'O que é a arquitetura cliente-servidor?', 'Modelo de rede em que dispositivos se conectam diretamente sem um servidor central', 'Modelo onde um dispositivo solicita serviços ou recursos e outro dispositivo os fornece', 'Modelo utilizado apenas em redes sem fio', 'Modelo de rede em que todos os dispositivos têm o mesmo nível de autoridade', 'alternativa_b'),
(185, 'Arquitetura de Rede de Computadores', 'O que é a técnica de multiplexação?', 'Processo de criar redes sem fio com maior capacidade', 'Técnica de codificação de dados para aumentar a segurança', 'Método de roteamento de pacotes em redes de longa distância', 'Técnica usada para transmitir múltiplos sinais sobre um único canal de comunicação', 'alternativa_d'),
(186, 'Arquitetura de Rede de Computadores', 'O que é um firewall?', 'Dispositivo utilizado para dividir redes físicas em sub-redes', 'Software que armazena e distribui dados de redes locais', 'Dispositivo ou software que controla o tráfego de rede com base em regras de segurança', 'Equipamento que distribui endereços IP dentro de uma rede', 'alternativa_c'),
(187, 'Arquitetura de Rede de Computadores', 'O que é o protocolo DNS?', 'Protocolo utilizado para compressão de dados em redes', 'Protocolo que garante a segurança em redes sem fio', 'Protocolo que converte nomes de domínio em endereços IP', 'Protocolo para transmissão de dados de áudio e vídeo', 'alternativa_c'),
(188, 'Arquitetura de Rede de Computadores', 'O que é uma rede LAN?', 'Uma rede sem fio utilizada para comunicação entre dispositivos móveis', 'Uma rede de longo alcance conectando várias cidades', 'Uma rede de área local, geralmente restrita a um único edifício ou campus', 'Uma rede de computadores em uma área extensa, como um país', 'alternativa_c'),
(189, 'Arquitetura de Rede de Computadores', 'O que é o protocolo ICMP?', 'Protocolo utilizado para estabelecer conexões TCP', 'Protocolo de transferência de arquivos em redes locais', 'Protocolo usado para enviar mensagens de controle e erro entre dispositivos em uma rede', 'Protocolo de segurança para autenticação de dispositivos', 'alternativa_c'),
(190, 'Arquitetura de Rede de Computadores', 'O que é o modelo TCP/IP?', 'Modelo de rede sem fio baseado em um único canal de comunicação', 'Modelo utilizado para redes de longa distância', 'Conjunto de protocolos usados para comunicação na internet e em redes locais', 'Modelo de rede onde os dispositivos não necessitam de um servidor central', 'alternativa_c'),
(191, 'Programação para Internet', 'Qual tag HTML é usada para criar um link?', 'div', 'link', 'a', 'p', 'alternativa_c'),
(192, 'Programação para Internet', 'Qual linguagem é usada para estilizar páginas web?', 'Python', 'JavaScript', 'CSS', 'C++', 'alternativa_c'),
(193, 'Programação para Internet', 'O que significa CSS?', 'Cascading Style Sheets', 'Central Style Sheets', 'Creative Style Sheets', 'Control Style Sheets', 'alternativa_a'),
(194, 'Programação para Internet', 'Em CSS, qual unidade de medida é relativa ao tamanho da fonte do elemento?', 'px', 'em', '%', 'rem', 'alternativa_b'),
(195, 'Programação para Internet', 'Qual é o símbolo usado para comentar uma linha de código em JavaScript?', '//', '/*', '<--', '#', 'alternativa_a'),
(196, 'Programação para Internet', 'Qual método JavaScript é usado para converter uma string em um número inteiro?', 'parseInt', 'parseFloat', 'toFixed', 'toString', 'alternativa_a'),
(197, 'Programação para Internet', 'Qual é a propriedade CSS usada para alterar a cor do texto?', 'background-color', 'text-color', 'color', 'font-color', 'alternativa_c'),
(198, 'Programação para Internet', 'O que faz a propriedade CSS display: flex;?', 'Define um layout de caixa de bloco.', 'Alinha elementos de forma vertical na página.', 'Cria um contêiner flexível para um layout de caixa, permitindo alinhamento e distribuição fácil dos itens.', 'Aplica uma margem automática ao contêiner.', 'alternativa_c'),
(199, 'Programação para Internet', 'Qual é a finalidade da função document.getElementById() em JavaScript?', 'Cria um novo elemento HTML com o ID especificado.', 'Retorna um elemento com o ID especificado do documento HTML.', 'Define o ID de um elemento HTML.', 'Remove o elemento com o ID especificado do documento HTML.', 'alternativa_b'),
(200, 'Programação para Internet', 'O que faz o método addEventListener() em JavaScript?', 'Adiciona um novo elemento ao DOM.', 'Adiciona um evento a um elemento HTML e define a função a ser chamada quando o evento ocorre.', 'Remove um evento de um elemento HTML.', 'Modifica a aparência de um elemento HTML.', 'alternativa_b'),
(201, 'Programação para Internet', 'Qual tag HTML é usada para inserir uma imagem?', 'image', 'img', 'src', 'picture', 'alternativa_b'),
(202, 'Programação para Internet', 'Qual atributo HTML é utilizado para especificar o endereço de uma imagem?', 'src', 'alt', 'href', 'title', 'alternativa_a'),
(203, 'Programação para Internet', 'Qual método JavaScript é usado para transformar uma string em letras maiúsculas?', 'toUpperCase', 'toLowerCase', 'capitalize', 'split', 'alternativa_a'),
(204, 'Programação para Internet', 'Em CSS, qual propriedade é usada para alterar o fundo de um elemento?', 'background-image', 'background-color', 'background-size', 'background-position', 'alternativa_b'),
(205, 'Programação para Internet', 'O que a propriedade CSS margin faz?', 'Define o espaço entre o conteúdo e a borda do elemento.', 'Define o espaço entre o elemento e outros elementos ao redor.', 'Define a cor de fundo do elemento.', 'Controla o tamanho da fonte.', 'alternativa_b'),
(206, 'Programação para Internet', 'Qual é a função da tag <head> em HTML?', 'Contém o conteúdo visível da página.', 'Contém os metadados e links para recursos externos.', 'Define o título da página.', 'Define o conteúdo de navegação.', 'alternativa_b'),
(207, 'Programação para Internet', 'O que a propriedade CSS ox-sizing faz?', 'Define a largura de um elemento.', 'Controla como as larguras e alturas de elementos são calculadas.', 'Determina a cor da borda de um elemento.', 'Define o espaço interno de um elemento.', 'alternativa_b'),
(208, 'Programação para Internet', 'O que é um callback em JavaScript?', 'Uma função que é passada como argumento para outra função.', 'Uma função que retorna um valor.', 'Uma função que modifica o DOM.', 'Uma função que é executada em loop.', 'alternativa_a'),
(209, 'Programação para Internet', 'O que a tag <link> é usada para fazer em HTML?', 'Definir um link para outro documento HTML.', 'Incluir um arquivo de estilo CSS externo.', 'Incluir uma imagem no documento.', 'Criar um botão de navegação.', 'alternativa_b'),
(210, 'Programação para Internet', 'Qual tag HTML é usada para criar uma lista ordenada?', '<ol>', '<ul>', '<li>', '<dl>', 'alternativa_a'),
(211, 'Programação para Internet', 'O que é o DOM em JavaScript?', 'Uma biblioteca de manipulação de eventos.', 'Uma API para manipular HTML e XML.', 'Um método de depuração.', 'Um tipo de estrutura de dados.', 'alternativa_b'),
(212, 'Eletricidade Instrumental', 'O que é eletricidade instrumental?', 'Uso de eletricidade para propósitos de iluminação', 'Uso de eletricidade para controle e medição de sistemas', 'Uso de eletricidade para aquecer materiais', 'Uso de eletricidade para alimentação de dispositivos domésticos', 'alternativa_b'),
(213, 'Eletricidade Instrumental', 'Qual é a unidade de medida da resistência elétrica?', 'Volts', 'Amperes', 'Ohms', 'Watts', 'alternativa_c'),
(214, 'Eletricidade Instrumental', 'Qual instrumento é usado para medir a corrente elétrica em um circuito?', 'Voltmímetro', 'Amperímetro', 'Ohmímetro', 'Multímetro', 'alternativa_b'),
(215, 'Eletricidade Instrumental', 'O que é um circuito elétrico?', 'Conjunto de elementos que conduzem eletricidade apenas em uma direção', 'Caminho fechado por onde a eletricidade pode fluir', 'Um dispositivo para gerar energia elétrica', 'Um tipo de resistor', 'alternativa_b'),
(216, 'Eletricidade Instrumental', 'O que faz um transformador elétrico?', 'Aumenta ou diminui a voltagem de um circuito', 'Controle de temperatura em circuitos', 'Mede a quantidade de eletricidade que passa em um circuito', 'Regula a corrente em circuitos de alta voltagem', 'alternativa_a'),
(217, 'Eletricidade Instrumental', 'Qual é a função de um disjuntor em um circuito elétrico?', 'Proteger o circuito contra sobrecargas e curtos-circuitos', 'Medir a corrente elétrica', 'Gerar eletricidade para o circuito', 'Aumentar a resistência elétrica', 'alternativa_a'),
(218, 'Eletricidade Instrumental', 'O que é uma corrente alternada (CA)?', 'Corrente elétrica que flui apenas em uma direção', 'Corrente elétrica que muda de direção periodicamente', 'Corrente elétrica que circula apenas em circuitos fechados', 'Corrente elétrica gerada por uma bateria', 'alternativa_b'),
(219, 'Eletricidade Instrumental', 'O que é um fusível elétrico?', 'Componente que controla a quantidade de eletricidade no circuito', 'Componente que protege o circuito de sobrecargas, queimando-se quando necessário', 'Componente utilizado para medir a resistência elétrica', 'Componente usado para aumentar a tensão do circuito', 'alternativa_b'),
(220, 'Eletricidade Instrumental', 'O que é a Lei de Ohm?', 'A relação entre corrente, resistência e voltagem em um circuito', 'A relação entre a corrente e a temperatura do material', 'A relação entre a voltagem e o tempo de condução da corrente', 'A relação entre a voltagem e a quantidade de energia gerada', 'alternativa_a'),
(221, 'Eletricidade Instrumental', 'Como se chama a unidade de medida de corrente elétrica?', 'Volts', 'Amperes', 'Ohms', 'Watts', 'alternativa_b'),
(222, 'Eletricidade Instrumental', 'Qual instrumento é usado para medir a voltagem em um circuito?', 'Amperímetro', 'Voltmímetro', 'Ohmímetro', 'Multímetro', 'alternativa_b'),
(223, 'Eletricidade Instrumental', 'O que é um multímetro?', 'Instrumento que mede a temperatura de um circuito', 'Instrumento utilizado para medir múltiplas grandezas elétricas, como corrente, voltagem e resistência', 'Instrumento para medir a velocidade de corrente', 'Instrumento para medir a quantidade de eletricidade gerada', 'alternativa_b'),
(224, 'Eletricidade Instrumental', 'Qual a função de um resistor em um circuito?', 'Gerar eletricidade', 'Armazenar energia', 'Limitar a quantidade de corrente que flui no circuito', 'Aumentar a voltagem do circuito', 'alternativa_c'),
(225, 'Eletricidade Instrumental', 'O que é um circuito em série?', 'Um circuito em que os componentes estão dispostos um ao lado do outro, com a corrente fluindo por todos de uma vez', 'Um circuito onde os componentes estão dispostos em paralelo, permitindo que a corrente flua por diferentes caminhos', 'Um circuito em que a corrente flui apenas por um componente', 'Um circuito em que os componentes são alimentados individualmente por fontes distintas', 'alternativa_a'),
(226, 'Eletricidade Instrumental', 'Qual a principal característica de um circuito em paralelo?', 'Os componentes estão dispostos de forma que a corrente flui por todos ao mesmo tempo', 'Cada componente tem sua própria linha de corrente e pode ser desligado independentemente', 'A corrente só passa por um único caminho', 'Os componentes não podem ser desligados individualmente', 'alternativa_b'),
(227, 'Eletricidade Instrumental', 'O que é a potência elétrica?', 'A quantidade de corrente que passa por um circuito', 'A taxa de fluxo de energia elétrica no circuito', 'A quantidade de voltagem aplicada em um circuito', 'A quantidade de resistência oferecida por um circuito', 'alternativa_b');

-- --------------------------------------------------------

--
-- Estrutura para tabela `questoes_respondidas`
--

CREATE TABLE `questoes_respondidas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `questao_id` int(11) NOT NULL,
  `resposta_usuario` varchar(50) NOT NULL,
  `resposta_correta` tinyint(1) NOT NULL,
  `disciplina` varchar(100) NOT NULL,
  `data_resposta` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `questoes_respondidas`
--

INSERT INTO `questoes_respondidas` (`id`, `usuario_id`, `questao_id`, `resposta_usuario`, `resposta_correta`, `disciplina`, `data_resposta`) VALUES
(61, 1, 52, 'alternativa_a', 0, 'Informática Básica', '2024-12-12 22:07:40'),
(62, 1, 53, 'alternativa_d', 0, 'Informática Básica', '2024-12-12 22:07:40'),
(63, 1, 54, 'alternativa_a', 0, 'Informática Básica', '2024-12-12 22:07:40'),
(64, 1, 55, 'alternativa_a', 0, 'Informática Básica', '2024-12-12 22:07:40'),
(65, 1, 56, 'alternativa_a', 0, 'Informática Básica', '2024-12-12 22:07:40'),
(66, 1, 62, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:07:56'),
(67, 1, 63, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:07:56'),
(68, 1, 64, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:07:56'),
(69, 1, 65, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:07:56'),
(70, 1, 66, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:07:56'),
(71, 1, 57, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:29'),
(72, 1, 58, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:29'),
(73, 1, 59, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:29'),
(74, 1, 60, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:29'),
(75, 1, 61, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:29'),
(76, 1, 67, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:56'),
(77, 1, 68, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:56'),
(78, 1, 69, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:56'),
(79, 1, 70, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:56'),
(80, 1, 71, 'alternativa_b', 0, 'Informática Básica', '2024-12-12 22:10:56'),
(81, 1, 72, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:08'),
(82, 1, 73, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:08'),
(83, 1, 74, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:08'),
(84, 1, 75, 'alternativa_a', 0, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:08'),
(85, 1, 76, 'alternativa_a', 0, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:08'),
(86, 1, 82, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:30'),
(87, 1, 83, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:30'),
(88, 1, 84, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:30'),
(89, 1, 85, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:30'),
(90, 1, 86, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:14:30'),
(91, 1, 8, 'alternativa_a', 0, 'Manutenção', '2024-12-12 22:15:16'),
(92, 1, 9, 'alternativa_a', 0, 'Manutenção', '2024-12-12 22:15:16'),
(93, 1, 10, 'alternativa_a', 0, 'Manutenção', '2024-12-12 22:15:16'),
(94, 1, 11, 'alternativa_a', 1, 'Manutenção', '2024-12-12 22:15:16'),
(95, 1, 12, 'alternativa_a', 0, 'Manutenção', '2024-12-12 22:15:16'),
(96, 1, 18, 'alternativa_a', 1, 'Manutenção', '2024-12-12 22:15:31'),
(97, 1, 19, 'alternativa_a', 1, 'Manutenção', '2024-12-12 22:15:31'),
(98, 1, 20, 'alternativa_a', 1, 'Manutenção', '2024-12-12 22:15:31'),
(99, 1, 21, 'alternativa_a', 1, 'Manutenção', '2024-12-12 22:15:31'),
(100, 1, 22, 'alternativa_a', 1, 'Manutenção', '2024-12-12 22:15:31'),
(101, 1, 32, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:17'),
(102, 1, 33, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:17'),
(103, 1, 34, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:17'),
(104, 1, 35, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:17'),
(105, 1, 36, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:17'),
(106, 1, 42, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:28'),
(107, 1, 43, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:28'),
(108, 1, 44, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:28'),
(109, 1, 45, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:28'),
(110, 1, 46, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:17:28'),
(111, 2, 72, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:28'),
(112, 2, 73, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:28'),
(113, 2, 74, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:28'),
(114, 2, 75, 'alternativa_a', 0, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:28'),
(115, 2, 76, 'alternativa_a', 0, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:28'),
(116, 1, 37, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:35:36'),
(117, 1, 38, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:35:36'),
(118, 1, 39, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:35:36'),
(119, 1, 40, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:35:36'),
(120, 1, 41, 'alternativa_d', 0, 'Eletrônica', '2024-12-12 22:35:36'),
(121, 2, 77, 'alternativa_a', 0, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:48'),
(122, 2, 78, 'alternativa_a', 0, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:48'),
(123, 2, 79, 'alternativa_a', 0, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:48'),
(124, 2, 80, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:48'),
(125, 2, 81, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-12 22:35:48'),
(126, 2, 82, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:12'),
(127, 2, 83, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:12'),
(128, 2, 84, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:12'),
(129, 2, 85, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:12'),
(130, 2, 86, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:12'),
(131, 2, 87, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:37'),
(132, 2, 88, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:37'),
(133, 2, 89, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:37'),
(134, 2, 90, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:37'),
(135, 2, 91, 'alternativa_a', 1, 'Fundamentos de Lógica e Algoritmos', '2024-12-13 16:44:37'),
(136, 2, 52, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 16:45:11'),
(137, 2, 53, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 16:45:11'),
(138, 2, 54, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 16:45:11'),
(139, 2, 55, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 16:45:11'),
(140, 2, 56, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 16:45:11'),
(141, 2, 1, 'alternativa_a', 0, 'Fundamento de Sistemas Operacionais', '2024-12-13 17:18:22'),
(142, 2, 57, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:24:38'),
(143, 2, 58, 'alternativa_c', 0, 'Informática Básica', '2024-12-13 17:24:38'),
(144, 2, 59, 'alternativa_d', 0, 'Informática Básica', '2024-12-13 17:24:38'),
(145, 2, 60, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:24:38'),
(146, 2, 61, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:24:38'),
(147, 2, 67, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:25:04'),
(148, 2, 68, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:25:04'),
(149, 2, 69, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:25:04'),
(150, 2, 70, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:25:04'),
(151, 2, 71, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:25:04'),
(152, 2, 62, 'alternativa_b', 0, 'Informática Básica', '2024-12-13 17:25:27'),
(153, 2, 63, 'alternativa_c', 0, 'Informática Básica', '2024-12-13 17:25:27'),
(154, 2, 64, 'alternativa_b', 0, 'Informática Básica', '2024-12-13 17:25:27'),
(155, 2, 65, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:25:27'),
(156, 2, 66, 'alternativa_a', 1, 'Informática Básica', '2024-12-13 17:25:27');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `pessoa`
--
ALTER TABLE `pessoa`
  ADD PRIMARY KEY (`usuario_id`);

--
-- Índices de tabela `questoes`
--
ALTER TABLE `questoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `questoes_respondidas`
--
ALTER TABLE `questoes_respondidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questao_id` (`questao_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `pessoa`
--
ALTER TABLE `pessoa`
  MODIFY `usuario_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `questoes`
--
ALTER TABLE `questoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=228;

--
-- AUTO_INCREMENT de tabela `questoes_respondidas`
--
ALTER TABLE `questoes_respondidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `questoes_respondidas`
--
ALTER TABLE `questoes_respondidas`
  ADD CONSTRAINT `questoes_respondidas_ibfk_1` FOREIGN KEY (`questao_id`) REFERENCES `questoes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();
include_once '../model/funcoes_pessoa.php';

if (isset($_SESSION['email'])) {
    $fPes = new funcoesPessoas();
    if ($fPes->apagarDadosDoUsuario($_SESSION['email'])) {
        session_destroy(); // Encerrar a sessão
        header('Location: home/cadastro.html'); // Redirecionar
        exit;
    } else {
        ?>
        <script type="text/javascript">
        alert("Erro ao apagar os dados.");
        </script>
        <?php
}
} else {
    ?>
    <script type="text/javascript">
    alert("Sessão não encontrada.");
    </script>
    <?php
}
?>

<?php
header("Content-Type: application/json");

try {
    // Configuração do banco de dados
    $dsn = "mysql:host=localhost;port=3306;dbname=ppi2";
    $usuario = "root";
    $senha = "123456";

    // Conexão com o banco
    $conexao = new PDO($dsn, $usuario, $senha);
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta SQL para buscar as questões
    $sql = "SELECT enunciado AS pergunta, alternativa_a, alternativa_b, alternativa_c, alternativa_d, resposta_correta 
            FROM questoes WHERE disciplina = 'sistemasOperacionais'";
    $comando = $conexao->prepare($sql);
    $comando->execute();

    // Transformar os resultados em um array
    $questoes = [];
    while ($row = $comando->fetch(PDO::FETCH_ASSOC)) {
        $questoes[] = [
            "pergunta" => $row["pergunta"],
            "respostas" => [
                $row["alternativa_a"],
                $row["alternativa_b"],
                $row["alternativa_c"],
                $row["alternativa_d"]
            ],
            "respostaCorreta" => $row["resposta_correta"]
        ];
    }

    // Retornar as questões em formato JSON
    echo json_encode($questoes);

} catch (PDOException $e) {
    // Em caso de erro, retornar a mensagem
    echo json_encode(["erro" => "Erro ao carregar questões: " . $e->getMessage()]);
}

?>

<?php
session_start();

// Verifica se o usuário está logado, caso contrário defina um usuário fictício ou ajuste conforme sua lógica.
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['usuario_id'] = 1; // Ajuste conforme o seu sistema
}

// Verifica se a disciplina foi passada via GET
if (!isset($_GET['disciplina'])) {
    die("Disciplina não especificada.");
}

$disciplina = $_GET['disciplina'];
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$questions_per_page = 5;
$offset = ($page - 1) * $questions_per_page;
$usuario_id = $_SESSION['usuario_id'];

try {
    $pdo = new PDO("mysql:host=localhost;dbname=ppi2", "root", "123456", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Conta o total de questões não respondidas para a disciplina
    $countStmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM questoes 
        WHERE disciplina = :disciplina
        AND id NOT IN (SELECT questao_id FROM questoes_respondidas WHERE usuario_id = :usuario_id)
    ");
    $countStmt->bindParam(':disciplina', $disciplina, PDO::PARAM_STR);
    $countStmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
    $countStmt->execute();
    $total_questoes = $countStmt->fetch()['total'];

    if ($total_questoes == 0) {
        // Exibe a mensagem de forma mais elegante e redireciona após 5 segundos
        ?>
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Quiz - <?php echo htmlspecialchars($disciplina); ?></title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
            <script>
                setTimeout(function(){
                    window.location.href = "index.php";
                }, 5000);
            </script>
        </head>
        <body class="bg-light">
            <div class="container my-5">
                <div class="alert alert-info text-center" role="alert">
                    <h4 class="alert-heading">Nenhuma questão não respondida encontrada</h4>
                    <p>Para a disciplina selecionada, não há mais questões pendentes de resposta.</p>
                    <hr>
                    <p class="mb-0">Você será redirecionado para a página inicial em breve.</p>
                </div>
            </div>
        </body>
        </html>
        <?php
        exit;
    }

    // Busca as questões não respondidas, paginadas
    $stmt = $pdo->prepare("
        SELECT * 
        FROM questoes 
        WHERE disciplina = :disciplina
        AND id NOT IN (SELECT questao_id FROM questoes_respondidas WHERE usuario_id = :usuario_id)
        LIMIT :limit OFFSET :offset
    ");
    $stmt->bindParam(':disciplina', $disciplina, PDO::PARAM_STR);
    $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $questions_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $questoes = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Erro ao acessar o banco de dados: " . $e->getMessage());
}

// Calcula o número total de páginas
$total_pages = ceil($total_questoes / $questions_per_page);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz - <?php echo htmlspecialchars($disciplina); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center glowing-text">Quiz: <?php echo htmlspecialchars($disciplina); ?></h1>
        <style>
          /* Estilo do título brilhante */
          
          .glowing-text {
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: 2.6rem; /* Ajuste conforme necessário */
            font-weight: bold;
            background: linear-gradient(45deg, #11bfcb, #ff00ea); /* Roxo -> Azul */
            background-size: 300% 300%;
            color: transparent;
            -webkit-background-clip: text;
            animation: gradient-animation 2s ease infinite;
          }
          section{
            margin-bottom:650px !important;
          }
    
    
          /* Animação do gradiente */
          @keyframes gradient-animation {
            0% {
              background-position: 0% 50%;
            }
            50% {
              background-position: 100% 50%;
            }
            100% {
              background-position: 0% 50%;
            }
          }
        </style>
        <form action="verificar_respostas.php" method="POST">
            <?php
                $iteration = 1;
                foreach ($questoes as $questao): ?>
                <div class="mb-4">
                    <h5><?php echo $iteration . ". " .htmlspecialchars($questao['enunciado']); ?></h5>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_a" id="q<?php echo $questao['id']; ?>_A" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_A" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_a']); ?></label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_b" id="q<?php echo $questao['id']; ?>_B" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_B" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_b']); ?></label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_c" id="q<?php echo $questao['id']; ?>_C" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_C" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_c']); ?></label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="resposta_<?php echo $questao['id']; ?>" value="alternativa_d" id="q<?php echo $questao['id']; ?>_D" class="form-check-input" required>
                        <label for="q<?php echo $questao['id']; ?>_D" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_d']); ?></label>
                    </div>
                </div>

            <?php $iteration++; endforeach; ?>

            <input type="hidden" name="disciplina" value="<?php echo htmlspecialchars($disciplina); ?>">
            <input type="hidden" name="page" value="<?php echo $page; ?>">

            <div class="text-center">
                <button type="submit" class="btn btn-primary">Enviar Respostas</button>
                <style>
                /* Botão "Comece a Estudar" */
          section .content .btn {
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            padding: 10px 29px;
            font-weight: bold; 
            font-size: 1rem;
            border: none;
            color: white;
            background: linear-gradient(45deg, #11bfcb, #ff00ea); /* Roxo -> Azul */
            background-size: 300% 300%;
            transition: all 0.4s ease;
          }
          .btn { 
            padding: 8px 19px;
            margin:10px;
            font-size: 1rem;
            border: none;
            color: white;
            background: linear-gradient(45deg, #11bfcb, #ff00ea); /* Roxo -> Azul */
            background-size: 300% 300%;
            transition: all 0.4s ease;
          }
    
          section .content .btn:hover {
            animation: gradient-animation 2s ease infinite;
            transform: scale(1.05); /* Efeito de aumento */
            color: white; /* Garantir contraste */
          }
          .btn:hover {
            animation: gradient-animation 2s ease infinite;
            transform: scale(1.05); /* Efeito de aumento */
            color: white; /* Garantir contraste */
          }
    
          /* Animação do gradiente */
          @keyframes gradient-animation {
            0% {
              background-position: 0% 50%;
            }
            50% {
              background-position: 100% 50%;
            }
            100% {
              background-position: 0% 50%;
            }
          }
        </style>
                <a href="index.php" class="btn btn-secondary">Página Inicial</a>
            </div>
        </form>

        <!-- Paginação -->
        <nav aria-label="Navegação de páginas" class="mt-4">
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?disciplina=<?php echo urlencode($disciplina); ?>&page=<?php echo $page - 1; ?>">Anterior</a>
                    </li>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?disciplina=<?php echo urlencode($disciplina); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?disciplina=<?php echo urlencode($disciplina); ?>&page=<?php echo $page + 1; ?>">Próxima</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
session_start();

// Verifica se a disciplina foi passada via GET
if (!isset($_GET['disciplina'])) {
    die("Disciplina não especificada.");
}

$disciplina = $_GET['disciplina'];
$usuario_id = $_SESSION['usuario_id'];

// Define quantas questões serão exibidas por página
$questoesPorPagina = 5;

// Obtém o número da página atual, padrão é 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $questoesPorPagina;

try {
    // Conexão com o banco de dados
    $pdo = new PDO("mysql:host=localhost;dbname=ppi2", "root", "123456", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Conta quantas questões não respondidas existem para esta disciplina
    $countStmt = $pdo->prepare("
        SELECT COUNT(*) as total
        FROM questoes
        WHERE disciplina = :disciplina
          AND id NOT IN (
              SELECT questao_id FROM questoes_respondidas WHERE usuario_id = :usuario_id
          )
    ");
    $countStmt->bindValue(':disciplina', $disciplina, PDO::PARAM_STR);
    $countStmt->bindValue(':usuario_id', $usuario_id, PDO::PARAM_INT);
    $countStmt->execute();
    $totalRow = $countStmt->fetch();
    $totalQuestoes = $totalRow['total'] ?? 0;

    if ($totalQuestoes == 0) {
        die("Você já respondeu todas as questões desta disciplina.");
    }

    // Seleciona as questões não respondidas para a página atual
    $stmt = $pdo->prepare("
        SELECT id, enunciado, alternativa_a, alternativa_b, alternativa_c, alternativa_d
        FROM questoes
        WHERE disciplina = :disciplina
          AND id NOT IN (
              SELECT questao_id FROM questoes_respondidas WHERE usuario_id = :usuario_id
          )
        LIMIT :limit OFFSET :offset
    ");

    $stmt->bindValue(':disciplina', $disciplina, PDO::PARAM_STR);
    $stmt->bindValue(':usuario_id', $usuario_id, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $questoesPorPagina, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $questoes = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Erro ao acessar o banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz - <?php echo htmlspecialchars($disciplina); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Quiz: <?php echo htmlspecialchars($disciplina); ?></h1>
        <form action="verificar_respostas.php" method="POST">
            <?php if (!empty($questoes)): ?>
                <?php foreach ($questoes as $questao): ?>
                    <div class="mb-4">
                        <h5><?php echo htmlspecialchars($questao['enunciado']); ?></h5>
                        <input type="hidden" name="questoes[]" value="<?php echo $questao['id']; ?>">

                        <div class="form-check">
                            <input type="radio" name="respostas[<?php echo $questao['id']; ?>]" value="alternativa_a" id="q<?php echo $questao['id']; ?>_A" class="form-check-input" required>
                            <label for="q<?php echo $questao['id']; ?>_A" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_a']); ?></label>
                        </div>
                        <div class="form-check">
                            <input type="radio" name="respostas[<?php echo $questao['id']; ?>]" value="alternativa_b" id="q<?php echo $questao['id']; ?>_B" class="form-check-input" required>
                            <label for="q<?php echo $questao['id']; ?>_B" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_b']); ?></label>
                        </div>
                        <div class="form-check">
                            <input type="radio" name="respostas[<?php echo $questao['id']; ?>]" value="alternativa_c" id="q<?php echo $questao['id']; ?>_C" class="form-check-input" required>
                            <label for="q<?php echo $questao['id']; ?>_C" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_c']); ?></label>
                        </div>
                        <div class="form-check">
                            <input type="radio" name="respostas[<?php echo $questao['id']; ?>]" value="alternativa_d" id="q<?php echo $questao['id']; ?>_D" class="form-check-input" required>
                            <label for="q<?php echo $questao['id']; ?>_D" class="form-check-label"><?php echo htmlspecialchars($questao['alternativa_d']); ?></label>
                        </div>
                    </div>
                <?php endforeach; ?>

                <input type="hidden" name="disciplina" value="<?php echo htmlspecialchars($disciplina); ?>">
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Enviar Respostas</button>
                    <a href="index.php" class="btn btn-secondary">Cancelar</a>
                </div>
            <?php else: ?>
                <p class="text-center">Não há mais questões não respondidas nesta disciplina.</p>
            <?php endif; ?>
        </form>

        <?php
        // Paginação
        $totalPaginas = ceil($totalQuestoes / $questoesPorPagina);
        if ($totalPaginas > 1):
        ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="quiz.php?disciplina=<?php echo urlencode($disciplina); ?>&page=<?php echo $page-1; ?>">Anterior</a>
                        </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="quiz.php?disciplina=<?php echo urlencode($disciplina); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPaginas): ?>
                        <li class="page-item">
                            <a class="page-link" href="quiz.php?disciplina=<?php echo urlencode($disciplina); ?>&page=<?php echo $page+1; ?>">Próxima</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

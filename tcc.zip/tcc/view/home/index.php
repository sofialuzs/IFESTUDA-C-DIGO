<?php
session_start();
$nomeUsuario = isset($_SESSION['nome']) ? $_SESSION['nome'] : null;

try {
    // Conexão com o banco de dados
    $pdo = new PDO("mysql:host=localhost;dbname=ppi2", "root", "123456", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Consulta para obter as disciplinas únicas da tabela 'questoes'
    $stmt = $pdo->query("SELECT DISTINCT disciplina FROM questoes");
    $disciplinas = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Erro ao conectar com o banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>IFEstuda</title>
    <link rel="stylesheet" href="sofi.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link rel="shortcut icon" href="image-removebg-preview.png" type="image/x-icon">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <img src="image-removebg-preview.png" alt="Logo" class="logo" />
        <a class="navbar-brand" href="#">IFEstuda</a>
        <style>
          .logo {
            position: absolute;
            top: 15px;
            left: 15px;
            width: 70px;
            height: auto;
          }
          .row{
            margin-top:14px!important;
          }
        </style>
      </div>
      
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo $nomeUsuario ? '#.html' : 'login.html'; ?>" id="button-login-usuario">
              <?php echo $nomeUsuario ? $nomeUsuario : 'Login'; ?>
            </a>
          </li>
          <li class="nav-item">
            <?php if ($nomeUsuario): ?>
              <button onclick="excluirSessao()" style="width: 63px;margin: 5px; border-radius:3.5px;border:none;background: #2173a3;color:white;">Sair</button>
            <?php endif; ?>
          </li>
          <li class="nav-item">
            <?php if ($nomeUsuario): ?>
              <a href="../apagarDados.php" class="btn btn-danger btn-sm" style="width: 104px;margin:3px;">Apagar Conta</a>
            <?php endif; ?>
          </li>
        </ul>
      </div>
    </nav>

    <section>
      <div class="content">
        <h1 class="glowing-text">IFEstuda</h1>
        <p>
          Seu portal para estudar e se preparar para as provas de forma
          eficiente!
        </p>
        <a href="#disciplinas" class="btn btn-primary mt-3">Comece a Estudar</a>
      </div>
      <style>
          /* Estilo do título brilhante */
          section .content .glowing-text {
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: 4rem; /* Ajuste conforme necessário */
            font-weight: bold;
            background: linear-gradient(45deg, #11bfcb, #ff00ea); /* Roxo -> Azul */
            background-size: 300% 300%;
            color: transparent;
            -webkit-background-clip: text;
            animation: gradient-animation 2s ease infinite;
          }
          section{
            margin-bottom:650px !important;
          }
    
          /* Botão "Comece a Estudar" */
          section .content .btn {
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            padding: 20px 29px;
            font-weight: bold; 
            font-size: 1rem;
            border: none;
            color: white;
            background: linear-gradient(45deg, #11bfcb, #ff00ea); /* Roxo -> Azul */
            background-size: 300% 300%;
            transition: all 0.4s ease;
          }
    
          section .content .btn:hover {
            animation: gradient-animation 2s ease infinite;
            transform: scale(1.05); /* Efeito de aumento */
            color: white; /* Garantir contraste */
          }
    
          /* Animação do gradiente */
          @keyframes gradient-animation {
            0% {
              background-position: 0% 50%;
            }
            50% {
              background-position: 100% 50%;
            }
            100% {
              background-position: 0% 50%;
            }
          }
        </style>
    </section>

    <section id="disciplinas" class="disciplinas container mt-5" style="margin-bottom: 650px;">
      <div class="row">
        <?php if (!empty($disciplinas)): ?>
          <?php foreach ($disciplinas as $disciplina): ?>
            <div class="col-md-4">
              <div class="card disciplina">
                <h2><?php echo htmlspecialchars($disciplina['disciplina']); ?></h2>
                <p>Explore os tópicos relacionados à disciplina "<?php echo htmlspecialchars($disciplina['disciplina']); ?>" e teste seus conhecimentos.</p>
                <a href="quiz.php?disciplina=<?php echo urlencode($disciplina['disciplina']); ?>" class="btn btn-light estude-btn">Começar Quiz</a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-center">Nenhuma disciplina disponível no momento.</p>
        <?php endif; ?>
      </div>
    </section>
    
    <footer>
      <div class="footer-container">
        <p>&copy; 2024 IFEstuda. Todos os direitos reservados.</p>
      </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      function excluirSessao() {
        window.location.href = "../excluirSessao.php";
      }
    </script>

    <script type="text/javascript">
      var nomeUsuario = <?php echo isset($_SESSION['nome']) ? json_encode($_SESSION['nome']) : 'null'; ?>;
      if (nomeUsuario) {
        document.getElementById("button-login-usuario").textContent = nomeUsuario;
      }
    </script>

  </body>
</html>

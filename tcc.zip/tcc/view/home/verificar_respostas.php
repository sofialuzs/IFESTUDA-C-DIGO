<?php
session_start();

if (!isset($_POST['disciplina'])) {
    die("Disciplina não especificada.");
}

if (!isset($_SESSION['usuario_id'])) {
    // Ajuste conforme sua lógica de autenticação
    $_SESSION['usuario_id'] = 1;
}

$disciplina = $_POST['disciplina'];
$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
$questions_per_page = 5;

try {
    $pdo = new PDO("mysql:host=localhost;dbname=ppi2", "root", "123456", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Identifica as questões respondidas a partir do POST
    $ids_respondidas = [];
    $respostas_usuario = []; 
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'resposta_') === 0) {
            $qid = (int)str_replace('resposta_', '', $key);
            $ids_respondidas[] = $qid;
            $respostas_usuario[$qid] = $value;
        }
    }

    if (empty($ids_respondidas)) {
        die("Nenhuma resposta encontrada.");
    }

    // Busca as questões respondidas pelo usuário com base nos IDs obtidos do POST
    $placeholders = rtrim(str_repeat('?,', count($ids_respondidas)), ',');
    $stmt = $pdo->prepare("SELECT * FROM questoes WHERE id IN ($placeholders)");
    $stmt->execute($ids_respondidas);
    $questoes = $stmt->fetchAll();

    // Conta total de questões para a disciplina (para fins de paginação/redirecionamento)
    $countStmt = $pdo->prepare("SELECT COUNT(*) as total FROM questoes WHERE disciplina = :disciplina");
    $countStmt->bindParam(':disciplina', $disciplina, PDO::PARAM_STR);
    $countStmt->execute();
    $total_questoes = $countStmt->fetch()['total'];
    $total_pages = ceil($total_questoes / $questions_per_page);

    // Monta o array de resultados
    $resultados = [];
    foreach ($questoes as $questao) {
        $qid = $questao['id'];
        $resposta_correta = $questao['resposta_correta'];
        $resposta_usuario = isset($respostas_usuario[$qid]) ? $respostas_usuario[$qid] : '';

        $resultados[] = [
            'questao_id' => $qid,
            'enunciado' => $questao['enunciado'],
            'alternativa_a' => $questao['alternativa_a'],
            'alternativa_b' => $questao['alternativa_b'],
            'alternativa_c' => $questao['alternativa_c'],
            'alternativa_d' => $questao['alternativa_d'],
            'correta' => $resposta_correta,
            'resposta_usuario' => $resposta_usuario
        ];
    }

    // Inserir as respostas no banco, se houver POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $insertStmt = $pdo->prepare("
            INSERT INTO questoes_respondidas (usuario_id, questao_id, resposta_usuario, resposta_correta, disciplina, data_resposta) 
            VALUES (:usuario_id, :questao_id, :resposta_usuario, :resposta_correta, :disciplina, NOW())
        ");

        foreach ($resultados as $res) {
            $resposta_usuario = $res['resposta_usuario'] ?? '';
            // Se não houver resposta, pula
            if ($resposta_usuario === '') {
                continue;
            }

            $insertStmt->execute([
                ':usuario_id' => $_SESSION['usuario_id'], 
                ':questao_id' => $res['questao_id'],
                ':resposta_usuario' => $resposta_usuario,
                ':resposta_correta' => ($res['resposta_usuario'] === $res['correta']) ? 1 : 0,
                ':disciplina' => $disciplina
            ]);
        }
    }

} catch (PDOException $e) {
    die("Erro ao acessar o banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Resultado</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style>
    .answer-correct {
        color: green;
        font-weight: bold;
    }
    .answer-incorrect {
        color: red;
        font-weight: bold;
    }
</style>
</head>
<body class="bg-light">
<div class="container my-5">
    <h1 class="mb-4 text-center">Resultados - Página <?php echo $page; ?></h1>
    
    <?php
    $iteration = 1; 
    foreach ($resultados as $resultado): 
    ?>
    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title"><?php echo $iteration . ". " . htmlspecialchars($resultado['enunciado']); ?></h5>
            <ul class="list-group list-group-flush">
                <?php
                $alternativas = ['alternativa_a','alternativa_b','alternativa_c','alternativa_d'];
                foreach ($alternativas as $alt):
                    $classe = '';
                    // Destaca a correta em verde.
                    if ($alt === $resultado['correta']) {
                        $classe = 'answer-correct';
                    }
                    // Se o usuário marcou essa alternativa e ela não é correta, destaca em vermelho
                    if ($resultado['resposta_usuario'] === $alt && $resultado['resposta_usuario'] !== $resultado['correta']) {
                        $classe = 'answer-incorrect';
                    }
                ?>
                <li class="list-group-item <?php echo $classe; ?>">
                    <?php echo htmlspecialchars($resultado[$alt]); ?>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php 
    $iteration++;
    endforeach; 
    ?>

    <div class="text-center mt-4">
        <a href="index.php" class="btn btn-secondary">Voltar</a>
    </div>
</div>

<?php if ($page < $total_pages): ?>
    <!-- Redireciona após 5 segundos para a próxima página -->
    <script>
        setTimeout(function(){
            window.location.href = "quiz.php?disciplina=<?php echo urlencode($disciplina); ?>&page=<?php echo $page + 1; ?>";
        }, 5000);
    </script>
<?php else: ?>
    <!-- Se não há mais páginas, redireciona após 1 segundo para index.php -->
    <script>
        setTimeout(function(){
            window.location.href = "index.php";
        }, 1000);
    </script>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

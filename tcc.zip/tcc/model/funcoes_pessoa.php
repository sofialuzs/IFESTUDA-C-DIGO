<?php

include_once 'modelo_pessoa.php';

class funcoesPessoas {

    private $dsn = "mysql:host=localhost;port=3306;dbname=ppi2"; // Atualize o DSN, se necessário
    private $usuario = "root";
    private $senha = "123456";

    private function conectar() {
        try {
            $conexao = new PDO($this->dsn, $this->usuario, $this->senha);
            $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conexao;
        } catch (PDOException $e) {
            echo "Erro na conexão com o banco de dados: " . $e->getMessage();
            exit;
        }
    }

    function inserir_cadastro($mPes) {
        try {
            $conexao = $this->conectar();
            $sql = "INSERT INTO pessoa (email, nome, senha) VALUES (:email, :nome, :senha)";
            $comando = $conexao->prepare($sql);
            $comando->bindParam(':email', $mPes->email, PDO::PARAM_STR);
            $comando->bindParam(':nome', $mPes->nome, PDO::PARAM_STR);
            $comando->bindParam(':senha', $mPes->senha, PDO::PARAM_STR);
            return $comando->execute();
        } catch (PDOException $e) {
            echo "Erro ao inserir cadastro: " . $e->getMessage();
            return false;
        }
    }

    function verificarEmailCadastro($email) {
        try {
            $conexao = $this->conectar();
            $sql = "SELECT * FROM pessoa WHERE email = :email";
            $comando = $conexao->prepare($sql);
            $comando->bindParam(':email', $email, PDO::PARAM_STR);
            $comando->execute();

            if ($comando->rowCount() > 0) {
                ?>
                <script type="text/javascript">
                    alert("Esse email já existe. Insira outro válido.");
                    window.location = "../view/home/cadastro.html";
                </script>
                <?php
            }
        } catch (PDOException $e) {
            echo "Erro ao verificar email: " . $e->getMessage();
        }
    }

    function loginUsuario($email, $senha) {
        try {
            $conexao = $this->conectar();
            $sql = "SELECT * FROM pessoa WHERE email = :email AND senha = :senha";
            $comando = $conexao->prepare($sql);
            $comando->bindParam(':email', $email, PDO::PARAM_STR);
            $comando->bindParam(':senha', $senha, PDO::PARAM_STR);
            $comando->execute();
            $usuario = $comando->fetch(PDO::FETCH_ASSOC);

            if ($usuario) {
                if (!isset($_SESSION)) {
                    session_start();	
                }

                $_SESSION['email'] = $usuario['email'];
                $_SESSION['nome'] = $usuario['nome'];
                $_SESSION['senha'] = $usuario['senha'];
		$_SESSION['usuario_id'] = $usuario['usuario_id'];

                ?>
                <script type="text/javascript">
                    alert("O login foi realizado.");
                    window.location = "../view/home/index.php";
                </script>
                <?php
            } else {
                ?>
                <script type="text/javascript">
                    alert("Email ou senha incorreto. Tente novamente.");
                    window.location = "../view/home/login.html";
                </script>
                <?php
            }
        } catch (PDOException $e) {
            echo "Erro no login: " . $e->getMessage();
        }
    }

    function apagarDadosDoUsuario($email) {
        try {
            $conexao = $this->conectar();
            $sql = "DELETE FROM pessoa WHERE email = :email";
            $comando = $conexao->prepare($sql);
            $comando->bindParam(':email', $email, PDO::PARAM_STR);
            return $comando->execute();
        } catch (PDOException $e) {
            echo "Erro ao apagar dados do usuário: " . $e->getMessage();
            return false;
        }
    }

}

?>

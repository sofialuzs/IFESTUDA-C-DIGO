<?php

class modeloPessoa {

    public $email;
    public $nome;
    public $senha;

    function __construct($e,$n,$s){
        $this->email = $e;
        $this->nome = $n;
        $this->senha = $s;
    }

}


?>